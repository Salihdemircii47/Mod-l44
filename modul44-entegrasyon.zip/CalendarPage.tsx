import BackendAppointmentManagement from "../components/BackendAppointmentManagement";
import BackendWeekCalendar from "../components/BackendWeekCalendar";

import { useEffect, useState } from "react";
import type { FormEvent } from "react";

import {
  AlertTriangle,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Plus,
  Trash2,
  X,
} from "lucide-react";

import WeekCalendar from "../components/WeekCalendar";

import type { SectorId } from "../data/sectors";
import type { Appointment } from "../types/appointment";

import { useAppointments } from "../features/appointments/hooks/useAppointments";
import { loadServices } from "../features/services/serviceStorage";

import { getBufferMinutes } from "../utils/availability";
import { getExtraResourcesBySector } from "../data/extraResources";

import {
  checkExtendedAvailability,
  suggestExtendedTimes,
} from "../utils/extraResourceAvailability";
import BackendAppointmentsPanel from "../components/BackendAppointmentsPanel";
import BackendAppointmentCreatePanel from "../components/BackendAppointmentCreatePanel";
type Props = {
  sectorId: SectorId;
};

const configs = {
  beauty: {
    label: "Kuaför & Güzellik",
    resourceLabel: "Personel",
    resources: [
      "Elif Demir",
      "Burak Yıldız",
      "Zeynep Arslan",
    ],
  },
  fleet: {
    label: "Vidanjör / Kombine / Kuka",
    resourceLabel: "Araç",
    resources: [
      "34 VDJ 101",
      "34 KMB 202",
      "34 KKA 303",
    ],
  },
  construction: {
    label: "Altyapı İnşaat",
    resourceLabel: "Ekip / İş Makinesi",
    resources: [
      "Keşif Ekibi A",
      "Ekskavatör 01",
      "Saha Ekibi B",
    ],
  },
};

const extraTypeLabels = {
  room: "Oda",
  equipment: "Ekipman",
  operator: "Operatör",
  vehicle: "Araç / İş Makinesi",
  area: "Çalışma Alanı",
};

const inputClass =
  "w-full rounded-xl border border-[#294361] bg-[#0b1728] px-4 py-3 text-sm text-white outline-none focus:border-cyan-400";

function dateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function addDays(
  value: string,
  amount: number
): string {
  const [year, month, day] = value
    .split("-")
    .map(Number);

  return dateKey(
    new Date(year, month - 1, day + amount)
  );
}

export default function CalendarPage({
  sectorId,
}: Props) {
  const config = configs[sectorId];

  // HİZMETLER
  // Artık ServicesPage yerine storage katmanından okuyoruz.
  const activeServices = loadServices()[sectorId].filter(
    (item) => item.active
  );

  // EK KAYNAKLAR
  const extraResources =
    getExtraResourcesBySector(sectorId).filter(
      (item) => item.active
    );

  // RANDEVU YÖNETİMİ
  // State ve localStorage işlemleri hook içerisinde.
  const {
    appointments,
    addAppointment,
    cancelAppointment: cancelStoredAppointment,
  } = useAppointments();

  // TAKVİM VE FORM STATE
  const [selectedDate, setSelectedDate] = useState(
    () => dateKey(new Date())
  );

  const [modalOpen, setModalOpen] = useState(false);

  const [customer, setCustomer] = useState("");

  const [service, setService] = useState<string>(
    () => activeServices[0]?.id ?? ""
  );

  const [resource, setResource] = useState<string>(
    config.resources[0]
  );

  const [
    additionalResource,
    setAdditionalResource,
  ] = useState("");

  const [
    selectedExtraIds,
    setSelectedExtraIds,
  ] = useState<string[]>([]);

  const [time, setTime] = useState("09:00");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [suggestions, setSuggestions] = useState<string[]>([]);

  // SEKTÖR DEĞİŞTİĞİNDE FORMU SIFIRLA
  useEffect(() => {
    const nextConfig = configs[sectorId];

    const firstService = loadServices()[sectorId].find(
      (item) => item.active
    );

    setService(firstService?.id ?? "");
    setResource(nextConfig.resources[0]);

    setAdditionalResource("");
    setSelectedExtraIds([]);

    setError("");
    setSuggestions([]);
    setMessage("");
    setModalOpen(false);
  }, [sectorId]);

  // RANDEVU FİLTRELERİ
  const sectorAppointments = appointments.filter(
    (item) =>
      item.sectorId === sectorId &&
      item.status !== "İptal"
  );

  const dayAppointments = sectorAppointments
    .filter((item) => item.date === selectedDate)
    .sort((a, b) => a.time.localeCompare(b.time));

  const usedResources = new Set(
    dayAppointments.flatMap((item) => [
      item.resource,
      ...(item.additionalResources ?? []),
    ])
  );

  const selectedService = activeServices.find(
    (item) => item.id === service
  );

  const displayDate = new Date(
    `${selectedDate}T12:00:00`
  ).toLocaleDateString("tr-TR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  // FORM HATALARINI TEMİZLE
  function clearFormFeedback() {
    setError("");
    setSuggestions([]);
  }

  // EK KAYNAK SEÇİMİ
  function toggleExtraResource(id: string) {
    setSelectedExtraIds((previous) =>
      previous.includes(id)
        ? previous.filter((item) => item !== id)
        : [...previous, id]
    );

    clearFormFeedback();
  }

  // YENİ RANDEVU MODALINI AÇ
  function openAppointmentModal() {
    clearFormFeedback();

    const currentService = loadServices()[sectorId].find(
      (item) => item.id === service && item.active
    );

    if (!currentService) {
      setService(activeServices[0]?.id ?? "");
    }

    setModalOpen(true);
  }

  // RANDEVU OLUŞTURMA
  function createAppointment(
    event: FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();
    clearFormFeedback();

    if (!customer.trim()) {
      setError("Müşteri veya iş adı giriniz.");
      return;
    }

    // En güncel katalog bilgisini oku.
    const currentService = loadServices()[sectorId].find(
      (item) =>
        item.id === service &&
        item.active
    );

    if (!currentService) {
      setError(
        "Geçerli ve aktif bir hizmet seçiniz."
      );
      return;
    }

    if (
      !Number.isFinite(currentService.duration) ||
      currentService.duration <= 0
    ) {
      setError("Hizmet süresi geçersiz.");
      return;
    }

    // Ana ve yardımcı kaynaklar
    const selectedResources = [
      resource,
      ...(additionalResource &&
      additionalResource !== resource
        ? [additionalResource]
        : []),
    ];

    // Ek kaynakların güncel durumunu kontrol et.
    const currentExtraResources =
      getExtraResourcesBySector(sectorId);

    const invalidExtraResource = selectedExtraIds.find(
      (id) =>
        !currentExtraResources.some(
          (item) =>
            item.id === id &&
            item.active
        )
    );

    if (invalidExtraResource) {
      setError(
        "Seçilen ek kaynaklardan biri artık aktif değil."
      );
      return;
    }

    // TÜM KAYNAKLAR İÇİN MÜSAİTLİK KONTROLÜ
    const request = {
      sectorId,
      serviceId: currentService.id,
      date: selectedDate,
      time,
      duration: currentService.duration,
      resources: selectedResources,
      extraResourceIds: [...selectedExtraIds],
      appointments,
      existingAppointments: appointments,
    };

    const result = checkExtendedAvailability(request);

    if (!result.available) {
      setError(result.reason);
      setSuggestions(suggestExtendedTimes(request));
      return;
    }

    const appointment: Appointment = {
      id: crypto.randomUUID(),
      sectorId,
      customer: customer.trim(),
      service: currentService.name,
      resource,
      additionalResources: selectedResources.slice(1),
      extraResourceIds: [...selectedExtraIds],
      date: selectedDate,
      time,
      duration: currentService.duration,
      status: "Onaylandı",
    };

    // useAppointments hook'u aracılığıyla kaydediyoruz.
    addAppointment(appointment);

    setMessage(
      "Randevu ve seçilen kaynaklar başarıyla rezerve edildi."
    );

    setCustomer("");
    setAdditionalResource("");
    setSelectedExtraIds([]);
    setSuggestions([]);
    setModalOpen(false);
  }

  // RANDEVU İPTALİ
  function handleCancelAppointment(id: string) {
    const confirmed = window.confirm(
      "Bu randevuyu iptal etmek istiyor musunuz?"
    );

    if (!confirmed) return;

    cancelStoredAppointment(id);

    setMessage(
      "Randevu iptal edildi. İlgili kaynaklar yeniden rezerve edilebilir."
    );
  }

  return (
    <div className="mx-auto max-w-[1500px] space-y-6">
      <BackendAppointmentManagement sectorId={sectorId} />
      <BackendWeekCalendar sectorId={sectorId} />
	<BackendAppointmentCreatePanel sectorId={sectorId} />
	<BackendAppointmentsPanel />
      {/* SAYFA BAŞLIĞI */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-[11px] font-bold tracking-[2px] text-cyan-400">
            MOD44 / PLANLAMA MERKEZİ
          </p>

          <h1 className="mt-3 text-3xl font-bold text-white">
            Randevu Takvimi
          </h1>

          <p className="mt-2 text-sm text-[#8299b7]">
            {config.label} için randevuları ve kaynakları yönetin.
          </p>
        </div>

        <button
          type="button"
          onClick={openAppointmentModal}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-500/20 hover:brightness-110"
        >
          <Plus size={18} />
          Yeni Randevu
        </button>
      </div>

      {/* ÖZET KARTLARI */}
      <div className="grid gap-4 sm:grid-cols-3">
        {[
          {
            label: "Günlük Randevu",
            value: dayAppointments.length,
          },
          {
            label: "Randevusu Olan Kaynak",
            value: usedResources.size,
          },
          {
            label: "Randevusu Olmayan Kaynak",
            value:
              config.resources.length -
              usedResources.size,
          },
        ].map((stat) => (
          <div
            key={stat.label}
            className="rounded-2xl border border-[#203653] bg-[#111e32] p-5"
          >
            <p className="text-xs text-[#8ba1bf]">
              {stat.label}
            </p>

            <p className="mt-3 text-3xl font-bold text-cyan-400">
              {stat.value}
            </p>
          </div>
        ))}
      </div>

      {/* HAFTALIK / GÜNLÜK / KAYNAK TAKVİMİ */}
      <WeekCalendar
        selectedDate={selectedDate}
        onDateChange={setSelectedDate}
        appointments={appointments.filter(
          (item) => item.sectorId === sectorId
        )}
        resources={config.resources}
      />

      {/* GÜNLÜK KAYNAK PLANLAMASI */}
      <section className="rounded-2xl border border-[#203653] bg-[#101d30] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <CalendarDays className="text-cyan-400" />

            <div>
              <h2 className="font-semibold capitalize text-white">
                {displayDate}
              </h2>

              <p className="text-xs text-[#7e94b3]">
                Kaynak bazlı günlük planlama
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              aria-label="Önceki gün"
              onClick={() =>
                setSelectedDate(
                  addDays(selectedDate, -1)
                )
              }
              className="rounded-lg border border-[#2a4262] p-2 text-white hover:bg-[#1c3451]"
            >
              <ChevronLeft size={19} />
            </button>

            <input
              type="date"
              aria-label="Randevu tarihi"
              value={selectedDate}
              onChange={(event) => {
                if (event.target.value) {
                  setSelectedDate(event.target.value);
                  clearFormFeedback();
                }
              }}
              className="rounded-lg border border-[#2a4262] bg-[#0b1728] p-2 text-sm text-white [color-scheme:dark]"
            />

            <button
              type="button"
              aria-label="Sonraki gün"
              onClick={() =>
                setSelectedDate(
                  addDays(selectedDate, 1)
                )
              }
              className="rounded-lg border border-[#2a4262] p-2 text-white hover:bg-[#1c3451]"
            >
              <ChevronRight size={19} />
            </button>
          </div>
        </div>

        {/* BAŞARI MESAJI */}
        {message && (
          <div
            role="status"
            className="mt-5 flex items-center gap-2 rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-3 text-sm text-emerald-300"
          >
            <CheckCircle2 size={17} />
            {message}
          </div>
        )}

        {/* KAYNAK KARTLARI */}
        <div className="mt-6 grid gap-3 lg:grid-cols-3">
          {config.resources.map((name) => {
            const resourceAppointments =
              dayAppointments.filter(
                (item) =>
                  item.resource === name ||
                  (
                    item.additionalResources ?? []
                  ).includes(name)
              );

            return (
              <div
                key={name}
                className="min-h-64 rounded-2xl border border-[#28405f] bg-[#0b1728] p-4"
              >
                <div className="mb-5 flex items-center justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-semibold text-white">
                      {name}
                    </h3>

                    <p className="mt-1 text-xs text-[#7c93b1]">
                      {config.resourceLabel}
                    </p>
                  </div>

                  <span className="rounded-full bg-blue-500/10 px-3 py-1 text-[11px] text-blue-300">
                    {resourceAppointments.length} iş
                  </span>
                </div>

                {resourceAppointments.length === 0 ? (
                  <div className="flex h-36 items-center justify-center rounded-xl border border-dashed border-[#29415f] text-center text-xs text-[#7189a9]">
                    Bu gün için kayıt yok
                  </div>
                ) : (
                  <div className="space-y-3">
                    {resourceAppointments.map(
                      (item) => (
                        <div
                          key={item.id}
                          className="rounded-xl border-l-4 border-cyan-400 bg-[#162d49] p-4"
                        >
                          <div className="flex items-center justify-between">
                            <span className="flex items-center gap-1 text-xs font-bold text-cyan-300">
                              <Clock3 size={14} />
                              {item.time}
                            </span>

                            <button
                              type="button"
                              aria-label={`${item.customer} randevusunu iptal et`}
                              title="Randevuyu iptal et"
                              onClick={() =>
                                handleCancelAppointment(
                                  item.id
                                )
                              }
                              className="text-[#8ba6c7] hover:text-red-400"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>

                          <p className="mt-3 text-sm font-bold text-white">
                            {item.customer}
                          </p>

                          <p className="mt-1 text-xs text-[#8ba4c2]">
                            {item.service} ·{" "}
                            {item.duration} dk
                          </p>

                          {(
                            item.additionalResources ?? []
                          ).length > 0 && (
                            <p className="mt-2 text-[11px] text-[#9ab4d2]">
                              Yardımcı:{" "}
                              {item.additionalResources?.join(
                                ", "
                              )}
                            </p>
                          )}

                          {(
                            item.extraResourceIds ?? []
                          ).length > 0 && (
                            <div className="mt-2 space-y-1">
                              {item.extraResourceIds?.map(
                                (id) => {
                                  const extra =
                                    getExtraResourcesBySector(
                                      sectorId
                                    ).find(
                                      (entry) =>
                                        entry.id === id
                                    );

                                  return (
                                    <p
                                      key={id}
                                      className="text-[11px] text-[#91abc9]"
                                    >
                                      •{" "}
                                      {extra?.name ??
                                        "Silinmiş kaynak"}
                                    </p>
                                  );
                                }
                              )}
                            </div>
                          )}

                          <span className="mt-3 inline-block rounded-md bg-emerald-400/10 px-2 py-1 text-[10px] text-emerald-400">
                            Onaylandı
                          </span>
                        </div>
                      )
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* YENİ RANDEVU MODALI */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="appointment-title"
            className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-3xl border border-[#2a4667] bg-[#111f35] p-6 shadow-2xl"
          >
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2
                  id="appointment-title"
                  className="text-xl font-bold text-white"
                >
                  Yeni Randevu
                </h2>

                <p className="mt-1 text-xs text-[#849bb9]">
                  {config.label}
                </p>
              </div>

              <button
                type="button"
                aria-label="Kapat"
                onClick={() => setModalOpen(false)}
                className="rounded-lg p-2 text-white hover:bg-[#203650]"
              >
                <X size={20} />
              </button>
            </div>

            <form
              onSubmit={createAppointment}
              className="space-y-4"
            >
              {/* MÜŞTERİ */}
              <label className="block space-y-2 text-xs text-[#9eb4d1]">
                <span>Müşteri / İş adı</span>

                <input
                  className={inputClass}
                  value={customer}
                  onChange={(event) =>
                    setCustomer(event.target.value)
                  }
                  placeholder="Örnek: ABC İnşaat"
                  maxLength={100}
                  required
                />
              </label>

              {/* HİZMET */}
              <label className="block space-y-2 text-xs text-[#9eb4d1]">
                <span>Hizmet</span>

                <select
                  className={inputClass}
                  value={service}
                  disabled={activeServices.length === 0}
                  onChange={(event) => {
                    setService(event.target.value);
                    clearFormFeedback();
                  }}
                >
                  {activeServices.length === 0 && (
                    <option value="">
                      Aktif hizmet bulunmuyor
                    </option>
                  )}

                  {activeServices.map((item) => (
                    <option
                      key={item.id}
                      value={item.id}
                    >
                      {item.name} ({item.duration} dk)
                    </option>
                  ))}
                </select>
              </label>

              {/* ANA KAYNAK */}
              <label className="block space-y-2 text-xs text-[#9eb4d1]">
                <span>{config.resourceLabel}</span>

                <select
                  className={inputClass}
                  value={resource}
                  onChange={(event) => {
                    const nextResource =
                      event.target.value;

                    setResource(nextResource);

                    if (
                      nextResource ===
                      additionalResource
                    ) {
                      setAdditionalResource("");
                    }

                    clearFormFeedback();
                  }}
                >
                  {config.resources.map((item) => (
                    <option
                      key={item}
                      value={item}
                    >
                      {item}
                    </option>
                  ))}
                </select>
              </label>

              {/* YARDIMCI KAYNAK */}
              <label className="block space-y-2 text-xs text-[#9eb4d1]">
                <span>
                  Yardımcı Kaynak (İsteğe Bağlı)
                </span>

                <select
                  className={inputClass}
                  value={additionalResource}
                  onChange={(event) => {
                    setAdditionalResource(
                      event.target.value
                    );
                    clearFormFeedback();
                  }}
                >
                  <option value="">
                    Yardımcı kaynak gerekli değil
                  </option>

                  {config.resources
                    .filter(
                      (item) => item !== resource
                    )
                    .map((item) => (
                      <option
                        key={item}
                        value={item}
                      >
                        {item}
                      </option>
                    ))}
                </select>

                <span className="block text-[11px] text-[#7893b5]">
                  Yardımcı kaynak da aynı saatte müsait
                  olmalıdır.
                </span>
              </label>

              {/* ODA / EKİPMAN / OPERATÖR */}
              <div className="rounded-2xl border border-[#294361] bg-[#0b1728] p-4">
                <h3 className="text-sm font-semibold text-white">
                  Oda, Ekipman ve Diğer Kaynaklar
                </h3>

                <p className="mt-1 text-xs text-[#839bb9]">
                  Bu randevuyla birlikte rezerve edilecek
                  ek kaynakları seçin.
                </p>

                {extraResources.length === 0 ? (
                  <p className="mt-3 text-xs text-[#829ab9]">
                    Aktif ek kaynak bulunmuyor.
                  </p>
                ) : (
                  <div className="mt-4 grid gap-2 sm:grid-cols-2">
                    {extraResources.map((item) => (
                      <label
                        key={item.id}
                        className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 transition ${
                          selectedExtraIds.includes(
                            item.id
                          )
                            ? "border-cyan-500/50 bg-cyan-500/10"
                            : "border-[#293e58] bg-[#12233a] hover:border-[#46688b]"
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={selectedExtraIds.includes(
                            item.id
                          )}
                          onChange={() =>
                            toggleExtraResource(
                              item.id
                            )
                          }
                          className="h-4 w-4 accent-cyan-400"
                        />

                        <div>
                          <p className="text-xs font-semibold text-white">
                            {item.name}
                          </p>

                          <p className="mt-1 text-[11px] text-[#839bb9]">
                            {extraTypeLabels[item.type]}
                          </p>
                        </div>
                      </label>
                    ))}
                  </div>
                )}

                <p className="mt-3 text-[11px] text-[#7893b5]">
                  Seçilen kaynaklar randevu süresince
                  başka bir işe atanamaz.
                </p>
              </div>

              {/* TARİH / SAAT */}
              <div className="grid grid-cols-2 gap-3">
                <label className="block space-y-2 text-xs text-[#9eb4d1]">
                  <span>Tarih</span>

                  <input
                    type="date"
                    className={`${inputClass} [color-scheme:dark]`}
                    value={selectedDate}
                    onChange={(event) => {
                      if (event.target.value) {
                        setSelectedDate(
                          event.target.value
                        );
                        clearFormFeedback();
                      }
                    }}
                    required
                  />
                </label>

                <label className="block space-y-2 text-xs text-[#9eb4d1]">
                  <span>Saat</span>

                  <input
                    type="time"
                    className={`${inputClass} [color-scheme:dark]`}
                    value={time}
                    onChange={(event) => {
                      setTime(event.target.value);
                      clearFormFeedback();
                    }}
                    required
                  />
                </label>
              </div>

              {/* REZERVASYON ÖZETİ */}
              <div className="rounded-xl bg-[#0b1728] p-3 text-xs text-[#90a9ca]">
                Süre:{" "}
                <strong className="text-white">
                  {selectedService?.duration ?? 0} dakika
                </strong>

                <span className="mx-2">•</span>
                Mesai: 09.00–18.00

                <p className="mt-2 text-[11px] text-[#8ba5c5]">
                  Hazırlık / temizlik tamponu:{" "}
                  {getBufferMinutes(sectorId)} dakika
                </p>

                <p className="mt-2 text-[11px] text-[#8ba5c5]">
                  Seçilen ek kaynak:{" "}
                  {selectedExtraIds.length}
                </p>
              </div>

              {/* HATA MESAJI */}
              {error && (
                <div
                  role="alert"
                  className="flex items-start gap-2 rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-xs text-red-300"
                >
                  <AlertTriangle
                    size={17}
                    className="shrink-0"
                  />
                  {error}
                </div>
              )}

              {/* ALTERNATİF SAATLER */}
              {suggestions.length > 0 && (
                <div className="rounded-xl border border-cyan-500/20 bg-cyan-500/5 p-4">
                  <p className="mb-3 text-xs font-semibold text-cyan-300">
                    Önerilen Müsait Saatler
                  </p>

                  <div className="flex flex-wrap gap-2">
                    {suggestions.map(
                      (suggestedTime) => (
                        <button
                          key={suggestedTime}
                          type="button"
                          onClick={() => {
                            setTime(suggestedTime);
                            clearFormFeedback();
                          }}
                          className="rounded-lg border border-cyan-500/30 bg-[#102a44] px-4 py-2 text-xs font-semibold text-cyan-300 hover:border-cyan-400 hover:bg-blue-600 hover:text-white"
                        >
                          {suggestedTime}
                        </button>
                      )
                    )}
                  </div>

                  <p className="mt-3 text-[11px] text-[#829ab9]">
                    Bir saate tıklayarak randevu
                    saatini değiştirebilirsiniz.
                  </p>
                </div>
              )}

              {/* KAYDET */}
              <button
                type="submit"
                disabled={!selectedService}
                className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 py-3 text-sm font-bold text-white hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Randevuyu Oluştur
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
